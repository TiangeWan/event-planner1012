$(function () {


});
function login() {
    var name = $(".username").val();
    var password = $(".password").val();
    name_passWord(function (data) {
        console.log(data)
        var index = 0;
        if (name != "" && password != "") {
            var i = 0
            while (i < data.length) {
                if (name = data[i].name && password == data[i].password) {
                    localStorage.setItem("name", i);
                   window.location = "index.html";
                    index = 1;
                    break
                } else {
                    index = 0
                }
                i++
            }
            if (index == 0) {
                alert("密码错误")
            }

        } else {
            alert("不能为空")
        }
    });
}
function name_passWord(callback) {
    $.ajax({
        type: "GET",
        url: "js/login.json",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (data) {
            callback(data)
        },
        error: function (data) {
            console.log("失败")
        }
    });
}
